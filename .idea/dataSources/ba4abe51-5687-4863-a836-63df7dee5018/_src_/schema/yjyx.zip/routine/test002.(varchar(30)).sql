CREATE PROCEDURE test002(IN name VARCHAR(30), OUT a_id INT)
  begin
     SELECT au.id INTO a_id FROM auth_user as au WHERE au.last_name =name;
END;
