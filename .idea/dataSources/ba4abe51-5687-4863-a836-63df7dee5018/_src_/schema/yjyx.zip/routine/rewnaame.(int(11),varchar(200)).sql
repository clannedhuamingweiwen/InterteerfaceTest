CREATE PROCEDURE rewnaame(IN p_num INT, IN name VARCHAR(200))
  BEGIN
     UPDATE yj_parent as p SET p.realname = name WHERE p.user_id =p_um;
  END;
