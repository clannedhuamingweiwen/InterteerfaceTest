CREATE PROCEDURE p_reregister(IN p_num INT, IN phone VARCHAR(200))
  BEGIN
     UPDATE yj_parent as p SET p.phonenumber = phone WHERE p.user_id =p_num;
     UPDATE auth_user as au SET au.username =phone WHERE au.id =p_num;
  END;
