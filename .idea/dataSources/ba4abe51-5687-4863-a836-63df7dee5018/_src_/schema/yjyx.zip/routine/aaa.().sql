CREATE PROCEDURE aaa()
  BEGIN 
    DECLARE pointer CURSOR 
    FOR
      SELECT au.password FROM auth_user as au WHERE au.last_name ="linux";
  END;
