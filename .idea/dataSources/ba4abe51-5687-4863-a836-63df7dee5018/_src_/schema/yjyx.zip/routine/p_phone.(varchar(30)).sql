CREATE PROCEDURE p_phone(IN s_name VARCHAR(30))
  BEGIN


Select p.phonenumber
from yj_parent_student_relation
as r
inner join
yj_parent
as p
on r.parent_id =p.id
inner join
yj_student
as s
on r.child_id = s.id
inner join
auth_user
as u
on s.user_id = u.id

where s.realname =s_name;
END;
