CREATE PROCEDURE s_reregister(IN s_num INT, IN s_phone VARCHAR(200))
  BEGIN
     UPDATE yj_student as s SET p.phonenumber = phone WHERE s.user_id =s_num;
     UPDATE auth_user as au SET au.username =phone WHERE au.id =s_num;
  END;
