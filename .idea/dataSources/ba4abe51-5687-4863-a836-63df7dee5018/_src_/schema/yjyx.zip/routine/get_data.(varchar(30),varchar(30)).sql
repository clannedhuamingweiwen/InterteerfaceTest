CREATE PROCEDURE get_data(IN name VARCHAR(30), IN name1 VARCHAR(30))
  BEGIN
     SELECT * FROM auth_user as au WHERE au.username =name
     and au.last_name=name1;
END;
