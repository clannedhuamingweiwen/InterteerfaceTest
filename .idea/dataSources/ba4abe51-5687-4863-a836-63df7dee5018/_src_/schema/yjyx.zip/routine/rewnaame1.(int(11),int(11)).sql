CREATE PROCEDURE rewnaame1(IN r_id INT, IN r_code INT)
  BEGIN
#      UPDATE yj_parent as p SET p.realname = name WHERE p.user_id =p_um;
    SELECT count(*)FROM yj_taskhistory WHERE recipient_id =r_id and finished =r_code;
  END;
