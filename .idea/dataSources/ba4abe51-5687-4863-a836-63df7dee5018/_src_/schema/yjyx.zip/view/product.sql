CREATE VIEW product AS
  (SELECT
     `yjyx`.`yj_product`.`id`   AS `id`,
     `yjyx`.`yj_product`.`name` AS `name`
   FROM `yjyx`.`yj_product`
   GROUP BY `yjyx`.`yj_product`.`id`);
